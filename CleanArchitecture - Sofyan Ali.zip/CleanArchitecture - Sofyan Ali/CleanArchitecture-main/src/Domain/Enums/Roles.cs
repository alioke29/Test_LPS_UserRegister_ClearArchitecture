﻿namespace CleanArchitecture.Domain.Enums;

public enum Roles
{
    User = 0,
    Admin = 1
}