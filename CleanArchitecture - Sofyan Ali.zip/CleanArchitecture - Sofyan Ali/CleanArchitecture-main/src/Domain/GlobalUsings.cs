﻿global using CleanArchitecture.Domain.Common;
global using CleanArchitecture.Domain.Entities;
global using CleanArchitecture.Domain.Enums;