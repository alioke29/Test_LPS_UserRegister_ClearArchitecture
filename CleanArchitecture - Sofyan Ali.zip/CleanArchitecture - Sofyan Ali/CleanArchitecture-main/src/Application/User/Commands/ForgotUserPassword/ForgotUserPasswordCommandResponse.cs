﻿namespace CleanArchitecture.Application.User.Commands.ForgotUserPassword;

public class ForgotUserPasswordCommandResponse
{
    public required string UserName { get; init; }
}