﻿namespace CleanArchitecture.Application.User.Commands.DeleteUser;

public class DeleteUserCommandResponse
{
    public required string Id { get; set; }
}