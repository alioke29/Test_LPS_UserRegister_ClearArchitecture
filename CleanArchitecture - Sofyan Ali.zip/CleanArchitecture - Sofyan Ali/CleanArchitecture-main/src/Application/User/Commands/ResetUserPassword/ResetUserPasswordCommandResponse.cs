﻿namespace CleanArchitecture.Application.User.Commands.ResetUserPassword;

public class ResetUserPasswordCommandResponse
{
    public required string UserName { get; init; }
}