﻿namespace CleanArchitecture.Application.User.Commands.UpdateUserRoles;

public class UpdateUserRolesCommandResponse
{
    public required string Id { get; init; }
}