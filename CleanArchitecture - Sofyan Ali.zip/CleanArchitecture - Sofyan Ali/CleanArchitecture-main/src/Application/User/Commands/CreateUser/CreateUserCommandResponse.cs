﻿namespace CleanArchitecture.Application.User.Commands.CreateUser;

public class CreateUserCommandResponse
{
    public required string Id { get; init; }
}