﻿namespace CleanArchitecture.Application.User.Commands.UpdateUserPassword;

public class UpdateUserPasswordCommandResponse
{
    public required string Id { get; init; }
}