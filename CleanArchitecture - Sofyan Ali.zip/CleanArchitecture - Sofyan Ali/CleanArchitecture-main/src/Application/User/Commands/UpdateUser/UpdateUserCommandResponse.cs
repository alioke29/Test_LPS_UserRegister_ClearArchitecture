﻿namespace CleanArchitecture.Application.User.Commands.UpdateUser;

public class UpdateUserCommandResponse
{
    public required string Id { get; init; }
}