﻿using FluentValidation;

namespace CleanArchitecture.Application.User.Queries.GetCurrentUser;

public class GetCurrentUserQueryValidator : AbstractValidator<GetCurrentUserQueryRequest>
{
}