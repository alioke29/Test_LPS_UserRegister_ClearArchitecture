﻿namespace CleanArchitecture.Application.Common.Exceptions;

public class ForbiddenAccessException : Exception
{
}