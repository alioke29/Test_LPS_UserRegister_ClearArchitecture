﻿namespace CleanArchitecture.Application.Authentication.Commands.Login;

public class LoginCommandResponse
{
    public required string Token { get; init; }
}